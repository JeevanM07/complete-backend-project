const express = require('express');
const mongoose = require('mongoose');
const passport = require("passport");
const bodyparser = require('body-parser');

//bring all routes
const auth = require('./routes/api/auth');
const profile = require('./routes/api/profile');
const question = require('./routes/api/question');

const app = express();

//middleware for bodyparser
app.use(bodyparser.urlencoded({extended: false}));
app.use(bodyparser.json());

//mongodb configuraiton
const db = require('./setup/myurl').mongoURL;

//attempt to connect to database
mongoose
.connect(db)
.then(() => {
    console.log('mongoDB connected successfully')
})
.catch(err => console.log(err));

//passport middleware
app.use(passport.initialize());

//config for jwt strategy
require('./strategies/jsonStratiges')(passport)

//just for testing ->route
app.get('/', (req, res) => {
    res.send("hey there big stack");
});

//actual routes
app.use('/api/auth', auth);
app.use('/api/question', question);
app.use('/api/profile', profile);

const port = process.env.PORT || 3000;

app.listen(port, () => console.log(`App is running at : ${port}`));