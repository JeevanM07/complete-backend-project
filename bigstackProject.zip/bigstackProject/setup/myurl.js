module.exports = {
    mongoURL:"mongodb+srv://new:jeevan123@pain.m57eezq.mongodb.net/test",
    secret: "mystrongsecret"
};